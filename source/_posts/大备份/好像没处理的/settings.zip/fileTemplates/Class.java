#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 *
 * @Author yupengtao
 * @Date ${DATE} ${HOUR}:${MINUTE}
 **/
public class ${NAME} {
}
